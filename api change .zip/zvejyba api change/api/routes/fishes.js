var express = require("express");
var router = express.Router();

const fishController = require("../controllers/fishController");

router.get("/", fishController.getAll);
router.get("/:id", fishController.getById);
router.post("/", fishController.create);
router.put("/:id", fishController.update);
router.delete("/:id", fishController.remove);

module.exports = router;
